alert('Hello JavaScript..!');
alert('문법에러'
